# Police station UI

Minecraft 1.20.1 / Forge 47.2.0 / Java 17

## 本次修复（fixed2）

- 修复难度选择页“困难模式”可能被底部区域挤压/遮挡的问题：三项位置根据游戏 GUI 高度自适应，绘制区域和点击区域使用同一套坐标。
- 修复固定存档检查：直接检查当前 Minecraft 实例目录下 `saves/休闲`、`saves/普通`、`saves/困难` 的实际文件夹和 `level.dat`，不再只依赖 `levelExists` 的判断。存在有效存档时调用 Minecraft 的 `loadLevel` 加载原存档；不会新建、删除或覆盖存档。
- 区分“存档目录不存在”和“目录存在但缺少 level.dat”，显示不同提示。
- 补充界面过渡：单人行动入口、难度选择、行动准备页和返回操作使用镜头推进、渐暗至黑场，再淡入目标界面；减少直接切屏感。
- 保持多人行动入口、主菜单布局、固定存档名称和难度背景设计不变。

## 固定存档位置

存档必须放在当前启动的 Minecraft 实例目录中：

- `saves/休闲/level.dat`
- `saves/普通/level.dat`
- `saves/困难/level.dat`

请把世界存档文件直接放入对应目录，不能多套一层同名文件夹。比如正确结构是 `saves/休闲/level.dat`，不是 `saves/休闲/休闲/level.dat`。

## 编译

在项目目录执行 `gradle --no-daemon clean build`，或使用仓库 GitHub Actions 工作流。构建产物位于 `build/libs/`。

注意：当前执行环境未安装 Gradle，尚未完成 Gradle 编译和 Minecraft 实机验证。请以 GitHub Actions 的实际构建结果为准。
