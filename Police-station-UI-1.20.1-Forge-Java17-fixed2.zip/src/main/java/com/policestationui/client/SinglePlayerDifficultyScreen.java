package com.policestationui.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SinglePlayerDifficultyScreen extends Screen {
    private static final String[] NAMES = {"休闲模式", "普通模式", "困难模式"};
    private static final String[] SUBTITLES = {"轻松体验", "标准行动难度", "高风险行动"};
    private final float[] scales = {1F, 1F, 1F};
    private int hovered = -1;
    private int fadeTicks;

    public SinglePlayerDifficultyScreen() { super(Component.literal("选择行动难度")); }

    private int panelWidth() { return Math.max(250, (int)(width * 0.31F)); }
    private int rowHeight() { return Math.max(34, Math.min(50, height / 12)); }
    private int rowTop() { return Math.max(78, Math.min(150, height / 4)); }
    private int rowGap() {
        int maxGap = Math.max(rowHeight() + 4, (height - 92 - rowHeight() - rowTop()) / 2);
        return Math.max(rowHeight() + 4, Math.min(92, maxGap));
    }

    @Override public void tick() { if (fadeTicks < 10) fadeTicks++; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int panelW = panelWidth();
        RenderSystem.setShaderTexture(0, PoliceStationMenuScreen.BACKGROUND);
        g.blit(PoliceStationMenuScreen.BACKGROUND, 0, 0, 0, 0, width, height, width, height);
        g.fill(0, 0, panelW, height, 0xB9000000);
        g.fill(panelW - 2, 0, panelW, height, 0x35FFFFFF);
        g.drawString(font, "单人行动", 34, 34, 0xFFFFFFFF, false);
        g.drawString(font, "SINGLE PLAYER", 35, 54, 0xFFBEBEBE, false);
        g.fill(35, 76, panelW - 30, 77, 0x55FFFFFF);

        int top = rowTop();
        int gap = rowGap();
        int rowH = rowHeight();
        hovered = -1;
        for (int i = 0; i < 3; i++) {
            int y = top + i * gap;
            if (mouseX >= 24 && mouseX <= panelW - 24 && mouseY >= y && mouseY <= y + rowH) hovered = i;
        }
        for (int i = 0; i < 3; i++) {
            float target = hovered == -1 ? 1F : (hovered == i ? 1.10F : 0.96F);
            scales[i] += (target - scales[i]) * 0.25F;
            int y = top + i * gap;
            if (i == hovered) {
                g.fill(24, y, panelW - 24, y + rowH, 0x35FFFFFF);
                g.fill(24, y, 27, y + rowH, 0xFFFFFFFF);
            }
            g.pose().pushPose();
            g.pose().translate(42, y + Math.max(5, (rowH - 38) / 2), 0);
            g.pose().scale(scales[i], scales[i], 1F);
            g.drawString(font, NAMES[i], 0, 0, 0xFFFFFFFF, false);
            g.drawString(font, SUBTITLES[i], 0, 19, 0xFFBDBDBD, false);
            g.pose().popPose();
        }
        g.drawString(font, "‹  返回主菜单", 28, height - 30, 0xFFE5E5E5, false);
        super.render(g, mouseX, mouseY, partialTick);
        int fade = (int)(255 * (1F - Math.min(1F, (fadeTicks + partialTick) / 10F)));
        if (fade > 0) g.fill(0, 0, width, height, (fade << 24));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        if (mouseY >= height - 42 && mouseX < 190) {
            Minecraft.getInstance().setScreen(new SinglePlayerTransitionScreen(new PoliceStationMenuScreen()));
            return true;
        }
        int top = rowTop();
        int gap = rowGap();
        int rowH = rowHeight();
        for (int i = 0; i < 3; i++) {
            int y = top + i * gap;
            if (mouseX >= 24 && mouseX <= panelWidth() - 24 && mouseY >= y && mouseY <= y + rowH) {
                Minecraft.getInstance().setScreen(new SinglePlayerTransitionScreen(new SinglePlayerModeScreen(i)));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public void onClose() {
        Minecraft.getInstance().setScreen(new SinglePlayerTransitionScreen(new PoliceStationMenuScreen()));
    }
}
