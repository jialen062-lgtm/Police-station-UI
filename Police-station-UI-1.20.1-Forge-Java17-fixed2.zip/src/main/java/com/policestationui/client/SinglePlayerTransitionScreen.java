package com.policestationui.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Cinematic push-in and fade-to-black between the police-station menu screens. */
public class SinglePlayerTransitionScreen extends Screen {
    private static final int DURATION = 22;
    private final Screen target;
    private int age;

    public SinglePlayerTransitionScreen() { this(new SinglePlayerDifficultyScreen()); }

    public SinglePlayerTransitionScreen(Screen target) {
        super(Component.literal("Transition"));
        this.target = target;
    }

    @Override
    public void tick() {
        age++;
        if (age >= DURATION) Minecraft.getInstance().setScreen(target);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        float progress = Math.min(1F, (age + partialTick) / DURATION);
        float eased = progress * progress * (3F - 2F * progress);
        float zoom = 1F + eased * 0.20F;
        graphics.pose().pushPose();
        graphics.pose().translate(-this.width * eased * 0.045F, -this.height * eased * 0.075F, 0);
        graphics.pose().translate(this.width / 2F, this.height / 2F, 0);
        graphics.pose().scale(zoom, zoom, 1F);
        graphics.pose().translate(-this.width / 2F, -this.height / 2F, 0);
        graphics.blit(PoliceStationMenuScreen.BACKGROUND, 0, 0, 0, 0, this.width, this.height, this.width, this.height);
        graphics.pose().popPose();

        // Hide the screen swap under a full fade, then let the destination fade back in.
        float fadeProgress = Math.min(1F, progress * 1.35F);
        int alpha = (int)(255F * fadeProgress * fadeProgress);
        graphics.fill(0, 0, this.width, this.height, (alpha << 24));
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
}
