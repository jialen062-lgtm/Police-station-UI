# Police station UI

独立 Minecraft 模组项目，不依赖 TACZYIGF。

## 开发环境
- Minecraft 1.20.1
- Forge 47.2.0
- Java 17
- ForgeGradle 6.x

## 当前首版内容
- 替换原版 TitleScreen 为警察局主题菜单
- 使用 `assets/police_station_ui/textures/gui/police_station_background.png` 作为背景
- 左侧半透明深色菜单面板
- 五个中文菜单入口：单人行动、多人行动、模组、选项、退出行动
- 鼠标悬停：当前选项放大，其他选项缩小；移出后恢复
- 菜单项连接到原版单人、多人、模组列表、选项和退出功能

## 构建
使用 Java 17 和 Gradle 8.8：
```bash
gradle --no-daemon clean build
```
产物位于 `build/libs/PoliceStationUI-1.0.0.jar`。

## 图片
背景图来自用户提供的警察局截图。可替换同名 PNG 资源以更换背景。
