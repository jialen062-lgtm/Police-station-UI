package com.policestationui.client;

import com.policestationui.PoliceStationUI;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.ModListScreen;
import net.minecraft.resources.ResourceLocation;

public class PoliceStationMenuScreen extends Screen {
    private static final ResourceLocation BACKGROUND =
            new ResourceLocation(PoliceStationUI.MODID, "textures/gui/police_station_background.png");

    private static final String[] LABELS = {
            "单人行动", "多人行动", "模组", "选项", "退出行动"
    };

    private final float[] scales = {1F, 1F, 1F, 1F, 1F};
    private int hoveredIndex = -1;

    public PoliceStationMenuScreen() {
        super(Component.literal("Police station UI"));
    }

    @Override
    protected void init() {
        // The menu is rendered and hit-tested manually so its hover animation can scale
        // the focused item without moving the other menu entries.
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int panelWidth = Math.max(230, (int) (this.width * 0.285F));
        int centerX = panelWidth / 2;
        int firstY = (int) (this.height * 0.28F);
        int spacing = Math.max(52, Math.min(76, this.height / 9));
        int buttonWidth = panelWidth - 36;
        int buttonHeight = 42;

        RenderSystem.setShaderTexture(0, BACKGROUND);
        graphics.blit(BACKGROUND, 0, 0, 0, 0, this.width, this.height,
                this.width, this.height);

        // Translucent dark left panel.
        graphics.fill(0, 0, panelWidth, this.height, 0xA9000000);
        graphics.fill(panelWidth - 2, 0, panelWidth, this.height, 0x35FFFFFF);

        hoveredIndex = -1;
        for (int i = 0; i < LABELS.length; i++) {
            int cy = firstY + i * spacing;
            if (mouseX >= centerX - buttonWidth / 2 && mouseX <= centerX + buttonWidth / 2
                    && mouseY >= cy - buttonHeight / 2 && mouseY <= cy + buttonHeight / 2) {
                hoveredIndex = i;
                break;
            }
        }

        for (int i = 0; i < LABELS.length; i++) {
            float target = hoveredIndex == -1 ? 1.0F : (i == hoveredIndex ? 1.25F : 0.90F);
            scales[i] += (target - scales[i]) * 0.28F;

            int cy = firstY + i * spacing;
            float scale = scales[i];
            int textColor = i == hoveredIndex ? 0xFFFFFFFF : 0xFFE8E8E8;

            graphics.pose().pushPose();
            graphics.pose().translate(centerX, cy, 0);
            graphics.pose().scale(scale, scale, 1.0F);

            if (i == hoveredIndex) {
                int glowWidth = font.width(LABELS[i]) + 30;
                graphics.fill(-glowWidth / 2, -17, glowWidth / 2, 18, 0x24FFFFFF);
                graphics.fill(-glowWidth / 2, 17, glowWidth / 2, 18, 0xBFFFFFFF);
            }

            graphics.drawCenteredString(font, LABELS[i], 0, -font.lineHeight / 2, textColor);
            graphics.pose().popPose();
        }

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int panelWidth = Math.max(230, (int) (this.width * 0.285F));
        int centerX = panelWidth / 2;
        int firstY = (int) (this.height * 0.28F);
        int spacing = Math.max(52, Math.min(76, this.height / 9));
        int buttonWidth = panelWidth - 36;
        int buttonHeight = 42;

        for (int i = 0; i < LABELS.length; i++) {
            int cy = firstY + i * spacing;
            float scale = scales[i];
            int halfW = (int) (buttonWidth * scale / 2F);
            int halfH = (int) (buttonHeight * scale / 2F);
            if (mouseX >= centerX - halfW && mouseX <= centerX + halfW
                    && mouseY >= cy - halfH && mouseY <= cy + halfH) {
                activate(i);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void activate(int index) {
        Minecraft minecraft = Minecraft.getInstance();
        switch (index) {
            case 0 -> minecraft.setScreen(new SelectWorldScreen(this));
            case 1 -> minecraft.setScreen(new JoinMultiplayerScreen(this));
            case 2 -> minecraft.setScreen(new ModListScreen(this));
            case 3 -> minecraft.setScreen(new OptionsScreen(this, minecraft.options));
            case 4 -> minecraft.stop();
            default -> { }
        }
    }

    @Override
    public void onClose() {
        // The title screen is intentionally replaced; Escape does not expose an empty parent screen.
        Minecraft.getInstance().setScreen(new PoliceStationMenuScreen());
    }
}
