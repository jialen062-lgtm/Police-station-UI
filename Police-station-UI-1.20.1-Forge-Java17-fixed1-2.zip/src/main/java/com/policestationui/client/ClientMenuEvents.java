package com.policestationui.client;

import com.policestationui.PoliceStationUI;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = PoliceStationUI.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientMenuEvents {
    private ClientMenuEvents() {}

    @SubscribeEvent
    public static void onScreenOpening(ScreenEvent.Opening event) {
        if (event.getScreen() instanceof TitleScreen
                && !(event.getScreen() instanceof PoliceStationMenuScreen)) {
            event.setNewScreen(new PoliceStationMenuScreen());
        }
    }
}
