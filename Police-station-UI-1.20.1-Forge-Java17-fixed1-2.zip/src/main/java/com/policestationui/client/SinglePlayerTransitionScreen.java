package com.policestationui.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** A short push-in transition from the main menu to the police-station entrance. */
public class SinglePlayerTransitionScreen extends Screen {
    private int age;
    private static final int DURATION = 30;

    public SinglePlayerTransitionScreen() {
        super(Component.literal("Entering single player"));
    }

    @Override
    public void tick() {
        age++;
        if (age >= DURATION) Minecraft.getInstance().setScreen(new SinglePlayerDifficultyScreen());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        float progress = Math.min(1F, (age + partialTick) / DURATION);
        float eased = progress * progress * (3F - 2F * progress);
        float zoom = 1F + eased * 0.16F;
        graphics.pose().pushPose();
        graphics.pose().translate(-this.width * eased * 0.035F, -this.height * eased * 0.07F, 0);
        graphics.pose().translate(this.width / 2F, this.height / 2F, 0);
        graphics.pose().scale(zoom, zoom, 1F);
        graphics.pose().translate(-this.width / 2F, -this.height / 2F, 0);
        graphics.blit(PoliceStationMenuScreen.BACKGROUND, 0, 0, 0, 0, this.width, this.height,
                this.width, this.height);
        graphics.pose().popPose();
        int fade = (int) (Math.min(1F, progress * 1.25F) * 105);
        graphics.fill(0, 0, this.width, this.height, (fade << 24));
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
}
