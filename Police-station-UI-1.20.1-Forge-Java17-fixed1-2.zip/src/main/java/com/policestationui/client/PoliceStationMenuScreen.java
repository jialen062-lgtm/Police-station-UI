package com.policestationui.client;

import com.policestationui.PoliceStationUI;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.ModListScreen;
import net.minecraft.resources.ResourceLocation;

public class PoliceStationMenuScreen extends Screen {
    static final ResourceLocation BACKGROUND =
            new ResourceLocation(PoliceStationUI.MODID, "textures/gui/police_station_background.png");
    private static final String[] LABELS = {"单人行动", "多人行动", "模组", "选项"};
    private final float[] scales = {1F, 1F, 1F, 1F};
    private int hoveredIndex = -1;
    private int exitHoverTicks;

    public PoliceStationMenuScreen() {
        super(Component.literal("Police station UI"));
    }

    @Override
    protected void init() { }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int panelWidth = Math.max(230, (int) (this.width * 0.285F));
        int centerX = panelWidth / 2;
        int firstY = (int) (this.height * 0.28F);
        int spacing = Math.max(52, Math.min(76, this.height / 9));
        int buttonWidth = panelWidth - 36;
        int buttonHeight = 42;
        int exitW = Math.max(112, font.width("退出行动") + 34);
        int exitH = 30;
        int exitX = this.width - exitW - 22;
        int exitY = this.height - exitH - 18;

        RenderSystem.setShaderTexture(0, BACKGROUND);
        graphics.blit(BACKGROUND, 0, 0, 0, 0, this.width, this.height, this.width, this.height);
        graphics.fill(0, 0, panelWidth, this.height, 0xA9000000);
        graphics.fill(panelWidth - 2, 0, panelWidth, this.height, 0x35FFFFFF);

        hoveredIndex = -1;
        for (int i = 0; i < LABELS.length; i++) {
            int cy = firstY + i * spacing;
            if (mouseX >= centerX - buttonWidth / 2 && mouseX <= centerX + buttonWidth / 2
                    && mouseY >= cy - buttonHeight / 2 && mouseY <= cy + buttonHeight / 2) {
                hoveredIndex = i;
                break;
            }
        }
        boolean exitHovered = mouseX >= exitX && mouseX <= exitX + exitW
                && mouseY >= exitY && mouseY <= exitY + exitH;
        exitHoverTicks += exitHovered ? 1 : -1;
        exitHoverTicks = Math.max(0, Math.min(5, exitHoverTicks));

        for (int i = 0; i < LABELS.length; i++) {
            float target = hoveredIndex == -1 ? 1.0F : (i == hoveredIndex ? 1.25F : 0.90F);
            scales[i] += (target - scales[i]) * 0.28F;
            int cy = firstY + i * spacing;
            graphics.pose().pushPose();
            graphics.pose().translate(centerX, cy, 0);
            graphics.pose().scale(scales[i], scales[i], 1.0F);
            if (i == hoveredIndex) {
                int glowWidth = font.width(LABELS[i]) + 30;
                graphics.fill(-glowWidth / 2, -17, glowWidth / 2, 18, 0x24FFFFFF);
                graphics.fill(-glowWidth / 2, 17, glowWidth / 2, 18, 0xBFFFFFFF);
            }
            graphics.drawCenteredString(font, LABELS[i], 0, -font.lineHeight / 2, 0xFFE8E8E8);
            graphics.pose().popPose();
        }

        int exitAlpha = exitHoverTicks > 0 ? 0x55 : 0x30;
        graphics.fill(exitX, exitY, exitX + exitW, exitY + exitH, (exitAlpha << 24) | 0xFFFFFF);
        if (exitHovered) graphics.fill(exitX, exitY + exitH - 2, exitX + exitW, exitY + exitH, 0xFFFFFFFF);
        graphics.drawCenteredString(font, "退出行动", exitX + exitW / 2, exitY + 10,
                exitHovered ? 0xFFFFFFFF : 0xFFE8E8E8);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int panelWidth = Math.max(230, (int) (this.width * 0.285F));
        int centerX = panelWidth / 2;
        int firstY = (int) (this.height * 0.28F);
        int spacing = Math.max(52, Math.min(76, this.height / 9));
        int buttonWidth = panelWidth - 36;
        int buttonHeight = 42;
        for (int i = 0; i < LABELS.length; i++) {
            int cy = firstY + i * spacing;
            int halfW = (int) (buttonWidth * scales[i] / 2F);
            int halfH = (int) (buttonHeight * scales[i] / 2F);
            if (mouseX >= centerX - halfW && mouseX <= centerX + halfW
                    && mouseY >= cy - halfH && mouseY <= cy + halfH) {
                activate(i);
                return true;
            }
        }
        int exitW = Math.max(112, font.width("退出行动") + 34);
        int exitX = this.width - exitW - 22;
        int exitY = this.height - 48;
        if (mouseX >= exitX && mouseX <= exitX + exitW && mouseY >= exitY && mouseY <= exitY + 30) {
            Minecraft.getInstance().stop();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void activate(int index) {
        Minecraft minecraft = Minecraft.getInstance();
        switch (index) {
            case 0 -> minecraft.setScreen(new SinglePlayerTransitionScreen());
            case 1 -> minecraft.setScreen(new JoinMultiplayerScreen(this));
            case 2 -> minecraft.setScreen(new ModListScreen(this));
            case 3 -> minecraft.setScreen(new OptionsScreen(this, minecraft.options));
            default -> { }
        }
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(new PoliceStationMenuScreen());
    }
}
