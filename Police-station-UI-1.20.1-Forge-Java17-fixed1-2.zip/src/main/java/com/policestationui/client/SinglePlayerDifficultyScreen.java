package com.policestationui.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SinglePlayerDifficultyScreen extends Screen {
    private static final String[] NAMES = {"休闲模式", "普通模式", "困难模式"};
    private static final String[] SUBTITLES = {"轻松体验", "标准行动难度", "高风险行动"};
    private final float[] scales = {1F, 1F, 1F};
    private int hovered = -1;

    public SinglePlayerDifficultyScreen() { super(Component.literal("选择行动难度")); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int panelW = Math.max(250, (int)(width * 0.31F));
        RenderSystem.setShaderTexture(0, PoliceStationMenuScreen.BACKGROUND);
        g.blit(PoliceStationMenuScreen.BACKGROUND, 0, 0, 0, 0, width, height, width, height);
        // Match the main menu's translucent black sidebar.
        g.fill(0, 0, panelW, height, 0xB9000000);
        g.fill(panelW - 2, 0, panelW, height, 0x35FFFFFF);
        g.drawString(font, "单人行动", 34, 34, 0xFFFFFFFF, false);
        g.drawString(font, "SINGLE PLAYER", 35, 54, 0xFFBEBEBE, false);
        g.fill(35, 76, panelW - 30, 77, 0x55FFFFFF);

        int rowTop = Math.max(118, (int)(height * 0.25F));
        int rowGap = Math.max(68, Math.min(92, height / 6));
        int rowH = 54;
        hovered = -1;
        for (int i = 0; i < 3; i++) {
            int y = rowTop + i * rowGap;
            if (mouseX >= 24 && mouseX <= panelW - 24 && mouseY >= y && mouseY <= y + rowH) hovered = i;
        }
        for (int i = 0; i < 3; i++) {
            float target = hovered == -1 ? 1F : (hovered == i ? 1.10F : 0.96F);
            scales[i] += (target - scales[i]) * 0.25F;
            int y = rowTop + i * rowGap;
            if (i == hovered) {
                g.fill(24, y, panelW - 24, y + rowH, 0x35FFFFFF);
                g.fill(24, y, 27, y + rowH, 0xFFFFFFFF);
            }
            g.pose().pushPose();
            g.pose().translate(42, y + 13, 0);
            g.pose().scale(scales[i], scales[i], 1F);
            g.drawString(font, NAMES[i], 0, 0, 0xFFFFFFFF, false);
            g.drawString(font, SUBTITLES[i], 0, 19, 0xFFBDBDBD, false);
            g.pose().popPose();
        }
        g.drawString(font, "‹  返回主菜单", 28, height - 30, 0xFFE5E5E5, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        if (mouseY >= height - 42 && mouseX < 190) {
            Minecraft.getInstance().setScreen(new PoliceStationMenuScreen());
            return true;
        }
        int rowTop = Math.max(118, (int)(height * 0.25F));
        int rowGap = Math.max(68, Math.min(92, height / 6));
        for (int i = 0; i < 3; i++) {
            int y = rowTop + i * rowGap;
            if (mouseX >= 24 && mouseX <= Math.max(250, (int)(width * 0.31F)) - 24 && mouseY >= y && mouseY <= y + 54) {
                Minecraft.getInstance().setScreen(new SinglePlayerModeScreen(i));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public void onClose() { Minecraft.getInstance().setScreen(new PoliceStationMenuScreen()); }
}
