package com.policestationui.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SinglePlayerModeScreen extends Screen {
    private static final String[] NAMES = {"休闲模式", "普通模式", "困难模式"};
    private static final String[] FOLDERS = {"休闲", "普通", "困难"};
    private final int mode;
    private boolean missingSave;

    public SinglePlayerModeScreen(int mode) {
        super(Component.literal("行动准备"));
        this.mode = Math.max(0, Math.min(2, mode));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        RenderSystem.setShaderTexture(0, PoliceStationMenuScreen.BACKGROUND);
        g.blit(PoliceStationMenuScreen.BACKGROUND, 0, 0, 0, 0, width, height, width, height);
        int panelW = Math.max(250, (int)(width * 0.31F));
        g.fill(0, 0, panelW, height, 0xB9000000);
        g.fill(panelW - 2, 0, panelW, height, 0x35FFFFFF);
        if (mode == 1) {
            g.fill(0, 0, width, height, 0x18000000);
            g.fill(width / 2 - 55, 35, width / 2 + 55, 145, 0x12D83A25);
        } else if (mode == 2) {
            g.fill(0, 0, width, height, 0x65000000);
            // Red sun tint and warm yellow sign glow, layered over the same fixed cover.
            int sx = (int)(width * 0.52F), sy = (int)(height * 0.12F);
            g.fill(sx - 25, sy - 25, sx + 25, sy + 25, 0x55FF2418);
            g.fill(sx - 17, sy - 17, sx + 17, sy + 17, 0x88E52A18);
            g.fill((int)(width * .36F), (int)(height * .18F), (int)(width * .72F), (int)(height * .29F), 0x35FFD34D);
        }
        g.drawString(font, NAMES[mode], 34, 34, 0xFFFFFFFF, false);
        g.drawString(font, "行动准备", 35, 55, 0xFFBEBEBE, false);
        g.fill(35, 77, panelW - 30, 78, 0x55FFFFFF);
        g.drawString(font, "固定行动存档", 36, 105, 0xFFEAEAEA, false);
        g.drawString(font, "存档位置：saves/" + FOLDERS[mode], 36, 128, 0xFFBDBDBD, false);
        g.drawString(font, "此难度仅有一个专属存档", 36, 151, 0xFFBDBDBD, false);
        if (missingSave) g.drawString(font, "存档尚未安装，请放入对应世界存档。", 36, 184, 0xFFFF7777, false);

        int startW = 142, startH = 34;
        int startX = width - startW - 28, startY = height - startH - 24;
        g.fill(startX, startY, startX + startW, startY + startH, 0xB9000000);
        g.fill(startX, startY, startX + startW, startY + 2, 0xFFFFFFFF);
        g.drawCenteredString(font, "开始行动", startX + startW / 2, startY + 12, 0xFFFFFFFF);
        g.drawString(font, "‹  返回难度选择", 28, height - 30, 0xFFE5E5E5, false);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        if (mouseY >= height - 42 && mouseX < 190) {
            Minecraft.getInstance().setScreen(new SinglePlayerDifficultyScreen());
            return true;
        }
        int startX = width - 170, startY = height - 58;
        if (mouseX >= startX && mouseX <= width - 28 && mouseY >= startY && mouseY <= height - 24) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.getLevelSource().levelExists(FOLDERS[mode])) {
                mc.createWorldOpenFlows().loadLevel(this, FOLDERS[mode]);
            } else {
                missingSave = true;
            }
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public void onClose() { Minecraft.getInstance().setScreen(new SinglePlayerDifficultyScreen()); }
}
