package com.policestationui;

import net.minecraftforge.fml.common.Mod;

@Mod(PoliceStationUI.MODID)
public class PoliceStationUI {
    public static final String MODID = "police_station_ui";

    public PoliceStationUI() {
        // Client menu replacement is registered through the client-only event subscriber.
    }
}
